﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            // C# Funktiot: Verolaskuri (Yhdessä päivä 9)
            Console.WriteLine("Syötä pallka: ");
            double wage = double.Parse(Console.ReadLine());

            Console.WriteLine("Syötä vero prosenttia : ");
            double percent  = double.Parse(Console.ReadLine());

            double np = nettoWage(wage, percent);
            Console.WriteLine($"Palkka netto on: {np}");

            Console.WriteLine("Press any key to exit");
            Console.ReadKey();
        }
        private static double nettoWage(double wage, double percent)
        {
            double nettopalkka = wage -(wage * percent / 100);
            return nettopalkka;
        }
    }
}

