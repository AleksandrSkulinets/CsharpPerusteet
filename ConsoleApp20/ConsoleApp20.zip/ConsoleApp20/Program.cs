﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp20
{
    class Program
    {
        static void Main(string[] args)
        {
            //
            //
            #region

            List<Trip> trips = new List<Trip>();

            bool userEndsLoop = false;

            while(userEndsLoop == false)
            {
                Console.Write("Syötä  matkan nimi: ");
                string name = Console.ReadLine();

                Console.Write("Syötä ajettu matka(km): ");
                double distance = double.Parse(Console.ReadLine());
                

                Console.Write("Syötä ajeneuvon keskikulutus(l/100km): ");
                double averageConsumption = double.Parse(Console.ReadLine());
                

                Console.Write("Syötä polttoaineen hinta(€/l): ");
                double fuelPrice = double.Parse(Console.ReadLine());

                
                trips.Add(new Trip(name , distance, averageConsumption, fuelPrice));

                Console.Write("Calculate another trip? (y): ");
                string input = Console.ReadLine().ToLower();

                if (input != "y") // Käyttäjä lopettaa sovelluksen
                {
                    userEndsLoop = true; // Kun tämä muuttuja on true, silmukka päättyy
                }
            }

            foreach(Trip t in trips)
            {
                // Lasku toimituksen voisi toteuttaa täällä käyttämällä objektien arvoja,
                // mutta yleensä luokan dataan liittyvät toiminnallisuudet
                // ovat osana itse luokkaa.
                // double test = t.AverageConsumption * t.FuelPrice * t.FuelPrice;

                Console.WriteLine($"Matkan {t.Name} hinta on {t.CalcullateCost()}");
            }

            

            Console.WriteLine("Press any key to exit");
            Console.ReadKey();
            #endregion

        }
    }
}
